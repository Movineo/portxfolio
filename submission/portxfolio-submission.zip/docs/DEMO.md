# Demo Guide

## Key Features to Showcase

1. AI Chat Assistant
   - Ask about skills and projects
   - Try suggested queries
   - Test natural conversation

2. Visual Elements
   - Toggle dark/light mode
   - Interact with 3D background
   - Check responsive design

3. Portfolio Content
   - View GitHub activity
   - Explore projects
   - Test contact form

## Example Interactions
- "Tell me about your skills"
- "What projects have you worked on?"
- "How can I contact you?"

## Tips
- Test on different devices
- Try various screen sizes
- Explore all sections