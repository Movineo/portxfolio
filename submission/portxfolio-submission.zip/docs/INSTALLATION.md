# Installation Guide

1. Clone the repository
2. Install dependencies: `npm install`
3. Configure environment variables
4. Start development server: `npm run dev`

## Environment Variables
- VITE_API_URL
- HUGGING_FACE_API_KEY

## Development
- Frontend: `npm run dev`
- Backend: `node server/index.js`

## Production
- Build: `npm run build`
- Start: `npm start`

## Testing
- Run tests: `npm test`
- Lint: `npm run lint`